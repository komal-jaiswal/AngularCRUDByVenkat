import { Component, OnInit } from '@angular/core';
import{FormControl,FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {

  constructor() { }
  favoritecolor=new FormControl('');
  favoritebird=new FormControl('');
  prePopulateFormControl(){
    debugger;
    this.favoritecolor.setValue('Komal');
    this.favoritebird.setValue("Penguin");
  }
 ngOnInit() {
  }
  userform=new FormGroup({
    firstName:new FormControl('',[Validators.required,Validators.maxLength(20)]),
    age:new FormControl(20,Validators.required),
    city:new FormControl(''),
    country:new FormControl({value:'India',disabled:true}),
  married:new FormControl({value:true})
  });
  employeeform=new FormGroup({
    firstname:new FormControl(''),
    lastname:new FormControl(''),
    address:new FormGroup({
      street:new FormControl(''),
      city:new FormControl(''),
      state:new FormControl(''),
      zip:new FormControl(''),
    })
  })
  submitFormThree(){
   console.log(this.employeeform.value);
  }
  onFormSubmit():void{
    console.log(this.userform.value);
    console.log('Name:' + this.userform.get('firstName').value);
    console.log('Age:' + this.userform.get('age').value);
    console.log('City:' + this.userform.get('city').value);
    console.log('Country:' + this.userform.get('country').value);
    const test=this.userform.get('married');
    test.value === true ? "working":"non working";
    console.log("working status:"+test.value);
  }
  prePopulate(){
   this.userform.setValue({
     firstName:"John",
     age:"24",
     city:"Bangalore",
     country:"India",
  
   })
  }
  pathUpdate(){
    this.employeeform.patchValue({
      firstName:"Nancy",
      address:{
        street:"ITPL Road"
      }
    })
  }

changeValue(event){
  debugger;
  if(event.target.checked == true){
    console.log("you are working")
  }
  else{
    console.log("you are not working");
  } 
}

// resetValue(){
//   this.name.reset();
// }
}
