import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListEmployeeComponent } from './employee/list-employee.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { EmployeeDisplayComponent } from './employee/employee-display.component';
import { CreateEmployeeCanDeactivateGuardService } from '../app/employee/create-employee-candeactivate-route-guard.service';
import { EmployeeDetailsComponent } from './employee/employee-details.component';  
import {ReactiveformComponent} from './reactiveFormDemo/reactiveform.component';
import { PageNotFoundComponent } from './page-not-found.component';
const routes: Routes = [
  
  {path:"list",component:ListEmployeeComponent},
  {path:"create",
   component:CreateEmployeeComponent,                  
  canDeactivate:[CreateEmployeeCanDeactivateGuardService]
}, 
{path:"employee/:id",component:EmployeeDetailsComponent},
{path:"reactiveform",component:ReactiveformComponent},
  {path:"",redirectTo:'/list',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
