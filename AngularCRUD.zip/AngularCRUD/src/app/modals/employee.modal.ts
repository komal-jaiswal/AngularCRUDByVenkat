export class Employee{
    
    Id:number;
    Name:string;
    Gender:string;
    Email?:string;
    PhoneNumber?:string;
    ContactPreference:string;
    DateOfBirth:Date;
    Department:string;
    IsActive:boolean;
    PhotoPath?:string;
   
}