
import {catchError} from 'rxjs/operators';
import {Injectable} from '@angular/core';
import {Employee} from '../modals/employee.modal';
import {Observable,   of } from 'rxjs';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
//import { delay ,  concatMap } from 'rxjs/internal/operators';

@Injectable()
export class EmployeeService
{
  constructor(private _http:HttpClient){}
   baseURL="http://localhost:3000/employees";
private listemployees:Employee[]=[
    {
        Id:1,
        Name:"dora",
        Gender:"female",
        Email:"dora@gmail.com",
        PhoneNumber:"8793002667",
        ContactPreference:"Phone",
        DateOfBirth:new Date('10/08/1993'),
        Department:"HR",
        IsActive:true,
        PhotoPath:"../assets/images/dora.jfif"
      },
      {
        Id:2,
        Name:"John",
        Gender:"male",
        Email:"john@accenture.com",
        PhoneNumber:"+4589076",
        ContactPreference:"Email",
        DateOfBirth:new Date('27/06/1990'),
        Department:"Payroll",
        IsActive:false,
        PhotoPath:"../assets/images/john.jpg"
      },
      {
        Id:3,
        Name:'Amy',
        Gender:'female',
        Email:'amy.cornerstone.com',
        PhoneNumber:'+459087',
        ContactPreference:"Email",
        DateOfBirth:new Date('07/03/1990'),
        Department:"IT",
        IsActive:true,
        PhotoPath:'../assets/images/Komal.jpg'
      }
];

getEmployees():Observable<Employee[]> {
    return this._http.get<Employee[]>(this.baseURL);
    //.pipe(catchError(this.handleError));
  }
//    private handleError(errorResponse:HttpErrorResponse){
//     if(errorResponse.error instanceof ErrorEvent){//then this is client side error
// console.error("client side error"+errorResponse.error.message);
//     }
//     else{
//       console.error("server side error"+errorResponse);
//     }
//     //this is to display user friendly error message
//     return new ErrorObservable('problem is with service');
//   }
   
getEmployee(id:number):Employee{
 debugger;
 return this.listemployees.find(e => e.Id === id);
 //return this._http.get<Employee>(`${this.baseURL}/${id}`);
 //.pipe(catchError(this.handleError))
 
}
addEmployee(employee:Employee):Observable<Employee>{
  //if(employee.id === null) //previously we were checking if id is null means create new emp else update existing one
 // {
    // const maxId=this.listemployees.reduce(function(e1,e2){
    //   return(e1.id > e2.id) ? e1:e2;
    // }).id;
    // employee.id=maxId+1;
    // this.listemployees.push(employee);
   return this._http.post<Employee>(this.baseURL,employee,{
      headers:new HttpHeaders({
        'Content-Type':'application/json'
      })
    });
    //.pipe(catchError(this.handleError));
  //}
  // else{
  //   const foundIndex=this.listemployees.findIndex(e=>e.id === employee.id);
  //   this.listemployees[foundIndex]=employee;
  // }
    
}
//added new method for put data
updateEmployee(employee:Employee):Observable<void>{
return this._http.put<void>(`${this.baseURL}/${employee.Id}`,employee,{
  headers:new HttpHeaders({
    'Content-Type':'application/json'
  })
})
//.pipe(catchError(this.handleError));
}
deleteEmployee(id:number):Observable<void>{
//  const deleteEmployee= this.listemployees.findIndex(e=>e.id==id);
//  if(deleteEmployee != -1){
//   this.listemployees.splice(deleteEmployee,1);
return this._http.delete<void>(`${this.baseURL}/${id}`);
 }


}