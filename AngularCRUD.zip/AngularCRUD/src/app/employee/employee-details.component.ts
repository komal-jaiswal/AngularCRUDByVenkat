import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {EmployeeService} from './employeeService';
import {Employee} from '../modals/employee.modal';
import {observable} from 'rxjs';


@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
employee:Employee;
private id:number;
  constructor(private _route:ActivatedRoute,
              private _employeeService:EmployeeService,
              private _router:Router) 
              { }

  ngOnInit() {
  //this.id= + this._route.snapshot.paramMap.get('id');//use snapshot.paramMap.get for angular 2 and above
  //use snapshot.params[''] for angular 2
  //mow will use parammap.get because we have to move forwardwithout going back to emp list
this._route.paramMap.subscribe(params=>{
  this.id= +params.get('id');
  this.employee=this._employeeService.getEmployee(this.id);
    console.log(this.employee);
})
    
  }
//this method used to display one employee at time and move next button

  displayNextEmployee(){
    if(this.id<=2)
    {
      this.id++;
    }
    else{
      this.id=1;
    }
this._router.navigate(['/employee',this.id],
{
  queryParamsHandling:'preserve'
})

  }
}
