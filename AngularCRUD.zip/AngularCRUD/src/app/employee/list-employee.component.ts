import { Component, OnInit } from '@angular/core';
import { Employee } from '../modals/employee.modal';
import {EmployeeService} from './employeeService'
import { Router, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {

  constructor(
    private _route: Router,
    private _actroute: ActivatedRoute,
    private _employeeService:EmployeeService) {
    //this.employees = this._actroute.snapshot.data['EmployeeListResolve'];
    //this.filteredEmployees = this.employees;
  
  }
  handleData: Employee;
  public employees: Employee[];
  private _searchTerm: string;
  filteredEmployees: Employee[];

  //displayEmployee:Employee;
  //private arrayIndex=1;
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(value: string) {
    debugger;
    this._searchTerm = value;
    this.filteredEmployees = this.getFilteredEmployees(value);
  }
  getFilteredEmployees(stringValue: string): Employee[] {
    if (!this.employees || !this.searchTerm) {
      return this.employees;
    }
    return this.filteredEmployees.filter(emp => emp.Name.toLocaleLowerCase().indexOf(stringValue.toLocaleLowerCase()) !== -1);

    //return this.filteredEmployees.filter(emp=>emp.name.toLocaleLowerCase().indexOf(stringValue.toLocaleLowerCase()) !== -1);
  }

  ngOnInit() {
    debugger;
    //we have commented this code as we are fetching data from resolver guard
        this._employeeService.getEmployees().subscribe((empList)=>{
        this.employees=empList,
        console.log("subscribe"+new Date().toTimeString());
        if(this._actroute.snapshot.queryParamMap.has("searchTerm"))
        {
         this.searchTerm= this._actroute.snapshot.queryParamMap.get("searchTerm")
        }
        else{
          console.log("else block"+new Date().toTimeString());
          this.filteredEmployees=this.employees;

      }
    });
       //this.filteredEmployees=this.employees;



    // console.log(this._actroute.snapshot.queryParamMap.get('searchTerm'));
    // console.log(this._actroute.snapshot.queryParamMap.getAll('searchTerm'));
    // console.log(this._actroute.snapshot.queryParamMap.keys);
    // console.log(this._actroute.snapshot.paramMap.keys);
    //this.displayEmployee=this.employees[0];
    //console.log(JSON.stringify(this.displayEmployee[0]));
  }
  handleOutputFromChild(outputdata: Employee) {
    this.handleData = outputdata;
  }
  handleDeleteNotifyEmployee(id:number){
    debugger;
    const deleteEmployee= this.filteredEmployees.findIndex(e=>e.Id==id);
    if(deleteEmployee != -1){
      this.filteredEmployees.splice(deleteEmployee,1);
    }
    
  }
 
  chaneEmployeeName() {
    // this.employees[0].name="Jordan";
    debugger;
    const newEmployee: Employee[] = Object.assign([], this.employees);
    newEmployee[0].Name = "Jordan";
    this.filteredEmployees = newEmployee;
    this.filteredEmployees = this.getFilteredEmployees(this.searchTerm);
  }
  //this is written just to demo of impure pipe.. when mouse moved still it execute pipe
  onMouseMove() {

  }
  //this method used to display one employee at time and move next button

  //   displayNextEmployee(){
  //     debugger;
  // if(this.arrayIndex<=1)
  // {
  //   this.displayEmployee=this.employees[this.arrayIndex];
  //   this.arrayIndex++;
  //  // console.log("previous employee:"+this.displayEmployee[this.arrayIndex-1]);
  //  // console.log("current Employee:"+this.displayEmployee[this.arrayIndex]);

  //   }
  //   else{
  //     this.displayEmployee=this.employees[0];
  //     this.arrayIndex=1;
  //   }

  //   }
}

