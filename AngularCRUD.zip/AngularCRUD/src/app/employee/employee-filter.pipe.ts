import { PipeTransform, Pipe } from '@angular/core';
import { Employee } from '../modals/employee.modal';

@Pipe({
    name: 'employeeFilter',
    pure:true
})

export class employeeFilterPipe implements PipeTransform{
    counter=0;
    transform(listEmployee:Employee[],searchTerm:string):Employee[]{
        console.log("counter is incrimented"+this.counter++);
if(!listEmployee || !searchTerm)
{
    return listEmployee;
}
return listEmployee.filter(emp=>emp.Name.toLocaleLowerCase().indexOf(searchTerm.toLocaleLowerCase())!== -1);
    }
}