import { Component, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { Employee } from '../modals/employee.modal';
import { ActivatedRoute, Router } from '@angular/router'
import {EmployeeService} from './employeeService';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-employee-display',
  templateUrl: './employee-display.component.html',
  styleUrls: ['./employee-display.component.css']
})

export class EmployeeDisplayComponent implements OnInit {

  constructor(private _route: ActivatedRoute, private _router: Router,private _employeeService:EmployeeService) { }

  private _employees: Employee;
  private selectedId: number;
  confirmDelete=false;
  isHiddenPanelExpanded=false;
  @Input() employees: Employee;
  @Input() searchTerm: string;
  @Output() notify: EventEmitter<Employee> = new EventEmitter<Employee>();
  @Output() deleteNotify:EventEmitter<number> = new EventEmitter<number>();
  handleEvent() {
    this.notify.emit(this.employees);
  }
  getEmployeeIsactive(): boolean {
    return this.employees.IsActive;
  }
  //this code to demo getter and setter in ANgular and display current and previous employee
  // set employees(val:Employee){
  //   console.log("previous  "+(this._employees?this._employees.name:"null"));
  // this._employees=val;
  // }

  // get employees():Employee{
  // return this._employees
  // }


  //
  ngOnInit() {
    this.selectedId = +this._route.snapshot.paramMap.get('id');

  }
  //this method is demo of onchanges to see current and previous employee
  ngOnChanges(changes: SimpleChanges) {
    //console.log(changes);
    // const previousEmployee=<Employee> changes.employees.previousValue;
    // const currentEmployee=<Employee> changes.employees.currentValue;
    // console.log("previous employee name    "+(previousEmployee ? previousEmployee.name : 'null'));
    // console.log("current employee name:     "+currentEmployee.name);

  }
  viewDetails(id: number) {
    this._router.navigate(['/employee', id],
      {
        queryParams: { 'searchTerm': this.searchTerm, 'TestValue': 'testvalue' },

      });
  }
  editDetails(id:number){
this._router.navigate(['/edit',id]);
  }
  deleteDetails(id:number){
    debugger;
    this._employeeService.deleteEmployee(id).subscribe(
      ()=>{console.log(`Employee with is = ${id} deleted`);
      (error)=>{console.log(error)}

    })
    this.deleteNotify.emit(id);
  }

}
