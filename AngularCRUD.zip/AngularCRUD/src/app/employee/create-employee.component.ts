import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Employee } from '../modals/employee.modal';
import { Department } from '../modals/Department';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/public_api';
import { EmployeeService } from './employeeService';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  datePickerConfig: Partial<BsDatepickerConfig>

  previewPhoto = false;
  private id: number;
  employees: Employee;
  panelTitle: string;
  @ViewChild('employeeForm') public createemployeeform: NgForm;
  //dateofbirth:Date=new Date(1993,08,10);


  departments: Department[] = [
    { id: 1, name: 'Help Desk' },
    { id: 2, name: 'HR' },
    { id: 3, name: 'IT' },
    { id: 4, name: 'Payroll' }
  ];
  static createemployeeform: any;
  constructor(private _employeeService: EmployeeService,
    private _router: Router,
    private _route: ActivatedRoute) { }
  //gender="male"; //checked by default as male
  //isActive=true
  ngOnInit() {
    debugger;
    this._route.paramMap.subscribe((params) =>
      this.id = +params.get('id'));
    if (this.id === 0) {
      this.employees =
        {
          Id: null,
          Name: null,
          Gender: null,
          Email: null,
          PhoneNumber: null,
          ContactPreference: null,
          DateOfBirth: null,
          Department: 'select',
          IsActive: true,
          PhotoPath: null
        };
      this.createemployeeform.reset();
      this.panelTitle = "create employee";
    }
    else {
      this.panelTitle = "edit employee";
      this.employees = this._employeeService.getEmployee(this.id);
      // .subscribe(
      //   (employee:Employee)=>{//success callback function
      //     this.employees=employee;
      //   },
      //   (error:any)=>{console.log(error);//eror callback function
      //   });
    }
  }
  saveEmployee(empForm: NgForm) {
    debugger;
    if (this.employees.Id === null) {
      //const newEmployee:Employee=Object.assign({},this.employees);//you can directly pass this employee object to the save method
      this._employeeService.addEmployee(this.employees).subscribe(//here we are paasing first call fun to subscribe method data which we are 
        //receiving from server after posting
        (data: Employee) => {
          console.log(data);
          this.createemployeeform.reset();
          this._router.navigate(['list']);
        },///now the second callback fun is error callback
        (error: any) => {
          console.log(error);
        }
      );
    }
    else {
      this._employeeService.updateEmployee(this.employees).subscribe(
        () => {
          this.createemployeeform.reset();
          this._router.navigate(['list']);
        },
        (error: any) => {
          console.log(error);
        }

      );
    }

  }
  togglePreviewPhoto() {
    this.previewPhoto = !this.previewPhoto;
  }
}
