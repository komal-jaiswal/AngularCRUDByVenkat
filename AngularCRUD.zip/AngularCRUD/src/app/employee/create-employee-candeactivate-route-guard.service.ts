import { CanDeactivate } from '@angular/router';
import {CreateEmployeeComponent} from './create-employee.component'
import {Injectable} from '@angular/core'

@Injectable()
export class CreateEmployeeCanDeactivateGuardService implements CanDeactivate<CreateEmployeeComponent>{
    canDeactivate(component : CreateEmployeeComponent):  boolean{
if(component.createemployeeform.dirty){
return confirm("do you really want to leave this page?");
    }

        return true;

}

}