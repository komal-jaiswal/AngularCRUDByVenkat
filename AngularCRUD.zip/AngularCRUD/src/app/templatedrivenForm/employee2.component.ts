import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-employee2',
  templateUrl: './employee2.component.html',
  styleUrls: ['./employee2.component.css']
})
export class Employee2Component implements OnInit {

  constructor(private formBuilder: FormBuilder  ) { }
  submitForm: FormGroup;
  submitted = false;
  Amount:number;
  ngOnInit() {
    this.configValidations();
  }
  configValidations() {
    debugger;
    this.submitForm = this.formBuilder.group({
      Amount: ['', [Validators.pattern(/^[0-9]*$/)]],
    });
   
}
get formObjects() {
  return this.submitForm.controls;
}
onSubmit() {
  debugger;
  this.submitted = true;

  
  if (this.submitForm.invalid) {
    return false;
  }
}
}
