import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { ListEmployeeComponent } from './employee/list-employee.component';
import { CreateEmployeeComponent } from './employee/create-employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { EmployeeService } from './employee/employeeService';
import { EmployeeDisplayComponent } from './employee/employee-display.component';
import { CreateEmployeeCanDeactivateGuardService } from './employee/create-employee-candeactivate-route-guard.service';
import { EmployeeDetailsComponent } from './employee/employee-details.component';
import { Employee2Component } from './templatedrivenForm/employee2.component';
import { employeeFilterPipe } from './employee/employee-filter.pipe';
import { PageNotFoundComponent } from './page-not-found.component';
import { EmployeeDetailscanActivateService } from './employee/employee-details-canActivate.service';
import { AccordianComponent } from './shared/accordian.component';
import { ReactiveformComponent } from './reactiveFormDemo/reactiveform.component';

//import {EmployeeListResolverService} from './employee/employeelist-resolver.service';

const routes: Routes = [
  {
    path: "list",
    component: ListEmployeeComponent,
    // resolve:{EmployeeListResolve:EmployeeListResolverService}
  },
  {
    path: "edit/:id",
    component: CreateEmployeeComponent,
    canDeactivate: [CreateEmployeeCanDeactivateGuardService]
  },
  {
    path: "employee2", component: Employee2Component
  },
  {
    path: "employee/:id",
    component: EmployeeDetailsComponent,
    canActivate: [EmployeeDetailscanActivateService]
  },
  { path: "", redirectTo: '/list', pathMatch: 'full' },
  { path: "**", component: PageNotFoundComponent },
];


@NgModule({
  declarations: [
    AppComponent,
    ListEmployeeComponent,
    CreateEmployeeComponent,
    EmployeeDisplayComponent,
    EmployeeDetailsComponent,
    Employee2Component,
    employeeFilterPipe,
    PageNotFoundComponent,
    AccordianComponent,
    ReactiveformComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    //enable tracing is used to log events of routing to console
   // RouterModule.forRoot(routes, { enableTracing: true }),
   
    RouterModule.forRoot(routes),
    FormsModule,
    BsDatepickerModule.forRoot(),
    HttpClientModule

  ],
  providers:
    [EmployeeService,
      CreateEmployeeCanDeactivateGuardService,
      EmployeeDetailscanActivateService],
  bootstrap: [AppComponent]
})
export class AppModule { }
